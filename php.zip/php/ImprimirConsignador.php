<?php

session_start();

require "conexion.php";
//require "../fpdf/fpdf.php";
require('../fpdf/multicellmax.php');
require('../fpdf/textbox.php');


//$codcurso = $_REQUEST['CodCur'];
//$codcurso2 = $_REQUEST['CodCur2'];
//$grupo    = $_REQUEST['grupo'];
$tablam2 = $_SESSION['tablam2'];

$query_tempo = "SELECT * FROM sistema.temporal WHERE id='1'";
$resultado_temp = pg_query($conexion, $query_tempo);
$obj_temporal = pg_fetch_object($resultado_temp);
$codigoConsulta = $obj_temporal->valor3;

$m = "m2";
$sql2 = "SELECT * FROM version_formato WHERE nombre_formato='$m'";
$result2 = pg_query($conexion, $sql2);
$obj2 = pg_fetch_object($result2);

$sql1 = "SELECT * FROM $tablam2 WHERE id ='$codigoConsulta'";
$resultado = pg_query($conexion, $sql1);
$obj = pg_fetch_object($resultado);

if ($obj->codigo_programa <> "26" && $obj->codigo_programa <> "30" && $obj->codigo_programa <> "31" && $obj->codigo_programa <> "32") {

    //$pdf = new FPDF("P", "mm", "Letter");
    $pdf = new PDF_TextBox("P", "mm", "Letter");
    $pdf->SetTitle('Formato Consignador Academico de contenidos');
    $pdf->AddPage();
    $pdf->Cell(60, 21, $pdf->Image("../assets/images/logo.png", 12, 12, 50), 1, 0);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(100, 21, mb_convert_encoding("Consignación Académica de Contenidos", 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "", 9);
    $pdf->Cell(15, 7, mb_convert_encoding("Código:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->codigo, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Versión:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->version, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Fecha:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->fecha, 'ISO-8859-1'), 1, 1, "L");
    $pdf->SetFont("Arial", "B", 9);
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(200, 5, mb_convert_encoding("Datos Principales", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "", 9);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->rect(10, 36, 200, 25);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(40, 5, mb_convert_encoding("Número Consignador:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding($obj->num_consignacion, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding("Fecha:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(20, 5, date("d-m-Y", strtotime($obj->fecha_consigna)), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(25, 5, mb_convert_encoding("Programa:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(100, 5, mb_convert_encoding($obj->nombre_programa, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(35, 5, mb_convert_encoding("Periodo Académico:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(25, 5, mb_convert_encoding($obj->codigo_periodo, 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(25, 5, mb_convert_encoding("Asignatura:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(25, 5, mb_convert_encoding($obj->codigo_asignatura, 'ISO-8859-1'), 1, 0, "C");
    $pdf->Cell(75, 5, mb_convert_encoding($obj->nombre_asignatura, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(12, 5, mb_convert_encoding("Grupo:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->grupo, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(10, 5, mb_convert_encoding("Sem:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->semestre, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding("H.T.T.S:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->htts, 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(30, 5, mb_convert_encoding("Nombre del Docente:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(95, 5, mb_convert_encoding($obj->nombre_docente, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(28, 5, mb_convert_encoding("Correo electrónico:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(46, 5, mb_convert_encoding("correo@", 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("Resultados del aprendizaje del programa", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->rect(10, 65, 200, 24);
    $pdf->SetFont("Arial", "", 7);
    $pdf->MultiCell(200, 3, mb_convert_encoding($obj->resultados_aprendizaje, 'ISO-8859-1'), 0,'J',0,5);
    //$pdf->SetXY(10,65);
    //$pdf->drawTextBox($obj->resultados_aprendizaje, 200, 25, 'J', 'T'); 
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("Intensidad Horaria Semanal", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(50, 5, mb_convert_encoding("Horas de trabajo teórico Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htts, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(50, 5, mb_convert_encoding("Horas de trabajo práctico Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htps, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(60, 5, mb_convert_encoding("Horas de trabajo independiente Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htis, 'ISO-8859-1'), 1, 1, "C");
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("DESARROLLO DE LA ASIGNATURA", 'ISO-8859-1'), 1, 1, "C", true);
    //$pdf->rect(10,105, 200, 5);
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(200, 6, mb_convert_encoding(" SEMANA                                                                       CONTENIDOS                                                                                                  ESTRATEGIAS METODOLÓGICAS          METODOS DE EVALUACIÓN", 'ISO-8859-1'), 1, 1, "L");
    /* $pdf->Cell(80, 5, mb_convert_encoding("",'ISO-8859-1'), 0, 0, "C");
$pdf->Cell(40, 5, mb_convert_encoding("ESTRATEGIAS METODOLÓGICAS",'ISO-8859-1'), 0, 0, "C");
$pdf->Cell(40, 5, mb_convert_encoding("METODOS DE EVALUACIÓN",'ISO-8859-1'), 0, 1, "C");
 */ //semana 1
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_titulo . " (" . $obj->s1_rangoi . " al " . $obj->s1_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s1_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_metodologia, 'ISO-8859-1'), 0,'J',0,4); 
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 96-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 96, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 2
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_titulo . " (" . $obj->s2_rangoi . " al " . $obj->s2_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s2_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 107-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 107, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 3
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_titulo . " (" . $obj->s3_rangoi . " al " . $obj->s3_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s3_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_metodologia, 'ISO-8859-1'), 0,'J',0,4);   
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 118-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 118, 200, 11);
    } 
    $pdf->Ln(8);
    //semana 4
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_titulo . " (" . $obj->s4_rangoi . " al " . $obj->s4_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s4_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 129-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 129, 200, 11);
    }
    $pdf->Ln(8);
    //semana 5
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_titulo . " (" . $obj->s5_rangoi . " al " . $obj->s5_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s5_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 140-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 140, 200, 11);
    }
    $pdf->Ln(8);
    //semana 6
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s6_titulo . " (" . $obj->s6_rangoi . " al " . $obj->s6_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s6_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s6_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s6_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 151-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 151, 200, 11);
    }
    $pdf->Ln(8);
    //semana 7
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s7_titulo . " (" . $obj->s7_rangoi . " al " . $obj->s7_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s7_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s7_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s7_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 162-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 162, 200, 11);
    }
    $pdf->Ln(8);
    //semana 8
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s8_titulo . " (" . $obj->s8_rangoi . " al " . $obj->s8_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s8_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s8_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s8_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 173-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 173, 200, 11);
    }
    $pdf->Ln(8);
    //semana 9
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s9_titulo . " (" . $obj->s9_rangoi . " al " . $obj->s9_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s9_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s9_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s9_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 184-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 184, 200, 11);
    }
    $pdf->Ln(8);
    //semana 10
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s10_titulo . " (" . $obj->s10_rangoi . " al " . $obj->s10_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s10_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s10_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s10_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 195-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 195, 200, 11);
    }
    $pdf->Ln(8);
    //semana 11
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s11_titulo . " (" . $obj->s11_rangoi . " al " . $obj->s11_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s11_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s11_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s11_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 206-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 206, 200, 11);
    }
    $pdf->Ln(8);
    //semana 12
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s12_titulo . " (" . $obj->s12_rangoi . " al " . $obj->s12_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s12_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s12_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s12_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=7;
        $pdf->rect(10, 217-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 217, 200, 11);
    }
    $pdf->Ln(30);

    //pie de pagina 1
    //$pdf->Ln(24);
    $pdf->AliasNbPages();
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(25, 5, mb_convert_encoding("Fecha y Hora de impresión", 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(5);
    $pdf->Cell(10, 5, date('d/m/Y'), 0, 0, 'L');
    $pdf->Cell(5);
    date_default_timezone_set("America/Bogota");
    $pdf->Cell(10, 5, date("h:i:sa"), 0, 0, 'L');
    $pdf->Cell(5);
    $pdf->Cell(80, 5, mb_convert_encoding($obj->nombre_asignatura, 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(0, 5, mb_convert_encoding('Página ', 'ISO-8859-1') . $pdf->PageNo() . '/{nb}', 0, 0, "R");
    //pagina 2
    $pdf->AddPage("P", "Letter");
    $pdf->Cell(60, 21, $pdf->Image("../assets/images/logo.png", 12, 12, 50), 1, 0);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(100, 21, mb_convert_encoding("Consignación Académica de Contenidos", 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "", 9);
    $pdf->Cell(15, 7, mb_convert_encoding("Código:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->codigo, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Versión:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->version, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Fecha:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->fecha, 'ISO-8859-1'), 1, 1, "L");
    //semana 13
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s13_titulo . " (" . $obj->s13_rangoi . " al " . $obj->s13_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s13_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s13_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s13_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->rect(10, 31, 200, 11);
    $pdf->Ln(8);
    //semana 14
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s14_titulo . " (" . $obj->s14_rangoi . " al " . $obj->s14_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s14_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s14_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s14_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->rect(10, 42, 200, 11);
    $pdf->Ln(8);
    //semana 15
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s15_titulo . " (" . $obj->s15_rangoi . " al " . $obj->s15_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s15_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s15_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s15_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->rect(10, 53, 200, 11);
    $pdf->Ln(8);    
    //semana 16
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s16_titulo . " (" . $obj->s16_rangoi . " al " . $obj->s16_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s16_contenidos, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s16_estrategia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s16_metodologia, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->rect(10, 64, 200, 11);
    $pdf->Ln(8);

    //
//semana 17
$pdf->SetFont("Arial", "", 6);
$y = $pdf->GetY();
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s17_titulo . " (" . $obj->s17_rangoi . " al " . $obj->s17_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(50, $y);
$pdf->MultiCell(80, 3, mb_convert_encoding($obj->s17_contenidos, 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(130, $y);
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s17_estrategia, 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(170, $y);
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s17_metodologia, 'ISO-8859-1'), 0,'J',0,4);
$pdf->rect(10, 75, 200, 11);
$pdf->Ln(8);

//semana 18
$pdf->SetFont("Arial", "", 6);
$y = $pdf->GetY();
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s18_titulo . " (" . $obj->s18_rangoi . " al " . $obj->s18_rangof . ")", 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(50, $y);
$pdf->MultiCell(80, 3, mb_convert_encoding($obj->s18_contenidos, 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(130, $y);
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s18_estrategia, 'ISO-8859-1'), 0,'J',0,4);
$pdf->SetXY(170, $y);
$pdf->MultiCell(40, 3, mb_convert_encoding($obj->s18_metodologia, 'ISO-8859-1'), 0,'J',0,4);
$pdf->rect(10, 86, 200, 11);
$pdf->Ln(8);

    //validacion
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("RESPONSABLES CONSIGNACION ACADÉMICA", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "", 6);
    $pdf->rect(10, 102, 65, 17);
    $pdf->rect(75, 102, 70, 17);
    $pdf->rect(145, 102, 65, 17);
    $pdf->Ln(5);
    $pdf->Cell(65, 3, mb_convert_encoding($obj->nombre_docente, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(70, 3, mb_convert_encoding($obj->validador1, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(65, 3, mb_convert_encoding($obj->validador2, 'ISO-8859-1'), 0, 1, "C");
    $pdf->SetFont("Arial", "", 5);
    $pdf->Cell(65, 2, mb_convert_encoding($obj->nombre_programa, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(70, 2, mb_convert_encoding("COORDINADOR " . $obj->nombre_programa, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(65, 2, mb_convert_encoding("VICERECTORIA ACADEMICA", 'ISO-8859-1'), 0, 1, "C");
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(65, 2, mb_convert_encoding("ELABORÓ", 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(70, 2, mb_convert_encoding("REVISÓ", 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(65, 2, mb_convert_encoding("APROBÓ", 'ISO-8859-1'), 0, 1, "C");
    $pdf->Ln(6);
    //pie de pagina 2
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(25, 5, mb_convert_encoding("Fecha y Hora de impresión", 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(5);
    $pdf->Cell(10, 5, date('d/m/Y'), 0, 0, 'L');
    $pdf->Cell(5);
    date_default_timezone_set("America/Bogota");
    $pdf->Cell(10, 5, date("h:i:sa"), 0, 0, 'L');
    $pdf->Cell(5);
    $pdf->Cell(80, 5, mb_convert_encoding($obj->nombre_asignatura, 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(0, 5, mb_convert_encoding('Página ', 'ISO-8859-1') . $pdf->PageNo() . '/{nb}', 0, 0, "R");
} else {

    //$pdf = new FPDF("P", "mm", "Letter");
    $pdf = new PDF_TextBox("P", "mm", "Letter");
    $pdf->SetTitle('Formato Consignador Academico de contenidos');
    $pdf->AddPage();
    $pdf->Cell(60, 21, $pdf->Image("../assets/images/logo.png", 12, 12, 50), 1, 0);
    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(100, 21, mb_convert_encoding("Consignación Académica de Contenidos", 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "", 9);
    $pdf->Cell(15, 7, mb_convert_encoding("Código:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->codigo, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Versión:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->version, 'ISO-8859-1'), 1, 1, "L");
    $pdf->Cell(160);
    $pdf->Cell(15, 7, mb_convert_encoding("Fecha:", 'ISO-8859-1'), 1, 0, "L");
    $pdf->Cell(25, 7, mb_convert_encoding($obj2->fecha, 'ISO-8859-1'), 1, 1, "L");
    $pdf->SetFont("Arial", "B", 9);
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(200, 5, mb_convert_encoding("Datos Principales", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "", 9);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->rect(10, 36, 200, 25);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(40, 5, mb_convert_encoding("Número Consignador:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding($obj->num_consignacion, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding("Fecha:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(20, 5, date("d-m-Y", strtotime($obj->fecha_consigna)), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(25, 5, mb_convert_encoding("Programa:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(100, 5, mb_convert_encoding($obj->nombre_programa, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(35, 5, mb_convert_encoding("Periodo Académico:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(25, 5, mb_convert_encoding($obj->codigo_periodo, 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(25, 5, mb_convert_encoding("Asignatura:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(25, 5, mb_convert_encoding($obj->codigo_asignatura, 'ISO-8859-1'), 1, 0, "C");
    $pdf->Cell(75, 5, mb_convert_encoding($obj->nombre_asignatura, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(12, 5, mb_convert_encoding("Grupo:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->grupo, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(10, 5, mb_convert_encoding("Sem:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->semestre, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(15, 5, mb_convert_encoding("H.T.T.S:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(8, 5, mb_convert_encoding($obj->htts, 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(30, 5, mb_convert_encoding("Nombre del Docente:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(95, 5, mb_convert_encoding($obj->nombre_docente, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(28, 5, mb_convert_encoding("Correo electrónico:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(46, 5, mb_convert_encoding("correo@", 'ISO-8859-1'), 1, 1, "C");
    $pdf->Cell(200, 1, "", 0, 1);
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("Resultados del aprendizaje del programa", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->rect(10, 65, 200, 25);
    $pdf->SetFont("Arial", "", 7);
    //$pdf->MultiCell(200, 3, mb_convert_encoding($obj->resultados_aprendizaje, 'ISO-8859-1'), 0,'J',0,5);
    $pdf->SetXY(10,65);
    $pdf->drawTextBox($obj->resultados_aprendizaje, 200, 25, 'J', 'T'); 
    $pdf->SetXY(10,90);
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("Intensidad Horaria Semanal", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(50, 5, mb_convert_encoding("Horas de trabajo teórico Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htts, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(50, 5, mb_convert_encoding("Horas de trabajo práctico Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htps, 'ISO-8859-1'), 1, 0, "C");
    $pdf->SetFont("Arial", "B", 8);
    $pdf->Cell(60, 5, mb_convert_encoding("Horas de trabajo independiente Semanal:", 'ISO-8859-1'), 0, 0, "L");
    $pdf->SetFont("Arial", "", 8);
    $pdf->Cell(10, 5, mb_convert_encoding($obj->htis, 'ISO-8859-1'), 1, 1, "C");
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("DESARROLLO DE LA ASIGNATURA", 'ISO-8859-1'), 1, 1, "C", true);
    //$pdf->rect(10,105, 200, 5);
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(200, 6, mb_convert_encoding(" SEMANA                                                                       CONTENIDOS                                                                                                  ESTRATEGIAS METODOLÓGICAS          METODOS DE EVALUACIÓN", 'ISO-8859-1'), 1, 1, "L");
        
    //semana 1 postgrado
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_titulo_p . " (" . $obj->s1_rangoi_p . " al " . $obj->s1_rangof_p . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s1_contenidos_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_estrategia_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s1_metodologia_p, 'ISO-8859-1'), 0,'J',0,4); 
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=6;
        $pdf->rect(10, 170-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 170, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 2 postgrados
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_titulo_p . " (" . $obj->s2_rangoi_p . " al " . $obj->s2_rangof_p . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s2_contenidos_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_estrategia_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s2_metodologia_p, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=6;
        $pdf->rect(10, 107-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 107, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 3 postgrados
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_titulo_p . " (" . $obj->s3_rangoi_p . " al " . $obj->s3_rangof_p . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s3_contenidos_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_estrategia_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s3_metodologia_p, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=6;
        $pdf->rect(10, 118-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 118, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 4
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_titulo_p . " (" . $obj->s4_rangoi_p . " al " . $obj->s4_rangof_p . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s4_contenidos_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_estrategia_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s4_metodologia_p, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=6;
        $pdf->rect(10, 129-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 129, 200, 11);
    }  
    $pdf->Ln(8);
    //semana 5
    $pdf->SetFont("Arial", "", 6);
    $y = $pdf->GetY();
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_titulo_p . " (" . $obj->s5_rangoi_p . " al " . $obj->s5_rangof_p . ")", 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(50, $y);
    $pdf->MultiCell(80, 3, mb_convert_encoding($obj->s5_contenidos_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(130, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_estrategia_p, 'ISO-8859-1'), 0,'J',0,4);
    $pdf->SetXY(170, $y);
    $pdf->MultiCell(40, 3, mb_convert_encoding($obj->s5_metodologia_p, 'ISO-8859-1'), 0,'J',0,4);
    if ($obj->resultados_aprendizaje== " " || $obj->resultados_aprendizaje==null) {
        $inc=6;
        $pdf->rect(10, 140-$inc, 200, 11);
    }else{   
        $pdf->rect(10, 140, 200, 11);
    }  
    $pdf->Ln(8);
    // paginas
    $pdf->AliasNbPages();
    //validacion
    $pdf->SetFillColor(181, 178, 178);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont("Arial", "B", 9);
    $pdf->Cell(200, 5, mb_convert_encoding("RESPONSABLES CONSIGNACION ACADÉMICA", 'ISO-8859-1'), 1, 1, "C", true);
    $pdf->SetFont("Arial", "", 6);
    $pdf->rect(10, 150, 65, 17);
    $pdf->rect(75, 150, 70, 17);
    $pdf->rect(145, 150, 65, 17);
    $pdf->Ln(5);
    $pdf->Cell(65, 3, mb_convert_encoding($obj->nombre_docente, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(70, 3, mb_convert_encoding($obj->validador1, 'ISO-8859-1'), 0, 0, "C");
    $pdf->Cell(65, 3, mb_convert_encoding($obj->validador2, 'ISO-8859-1'), 0, 1, "C");
    $y = $pdf->GetY();
    $pdf->SetFont("Arial", "", 5);
    $pdf->MultiCell(65, 2, mb_convert_encoding($obj->nombre_programa, 'ISO-8859-1'), 0, "C",0);
    $pdf->SetXY(75, $y);
    $pdf->MultiCell(70, 2, mb_convert_encoding("COORDINADOR " . $obj->nombre_programa, 'ISO-8859-1'), 0, "C", 0);
    $pdf->SetXY(145, $y);
    $pdf->Cell(65, 2, mb_convert_encoding("VICERECTORIA ACADEMICA", 'ISO-8859-1'), 0, 1, "C");
    $pdf->Ln(2);
    $y = $pdf->GetY();
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(65, 2, mb_convert_encoding("ELABORÓ", 'ISO-8859-1'), 0, 0, "C");
    $pdf->SetXY(75, $y);
    $pdf->Cell(70, 2, mb_convert_encoding("REVISÓ", 'ISO-8859-1'), 0, 0, "C");
    $pdf->SetXY(145, $y);
    $pdf->Cell(65, 2, mb_convert_encoding("APROBÓ", 'ISO-8859-1'), 0, 1, "C");
    $pdf->Ln(6);
    //pie de pagina 
    $pdf->SetFont("Arial", "", 6);
    $pdf->Cell(25, 5, mb_convert_encoding("Fecha y Hora de impresión", 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(5);
    $pdf->Cell(10, 5, date('d/m/Y'), 0, 0, 'L');
    $pdf->Cell(5);
    date_default_timezone_set("America/Bogota");
    $pdf->Cell(10, 5, date("h:i:sa"), 0, 0, 'L');
    $pdf->Cell(5);
    $pdf->Cell(80, 5, mb_convert_encoding($obj->nombre_asignatura, 'ISO-8859-1'), 0, 0, "L");
    $pdf->Cell(0, 5, mb_convert_encoding('Página ', 'ISO-8859-1') . $pdf->PageNo() . '/{nb}', 0, 0, "R");
}

$pdf->Output('I', 'reporte_consignador_academico.pdf');
