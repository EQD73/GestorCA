<?php
session_start();

include ('conexion.php');
$tablam1=$_SESSION['tablam1'];

$codcurso=$_REQUEST['codasig'];
$codgrupo=$_REQUEST['codgrup'];

$sql="SELECT * FROM $tablam1 WHERE codigo_asignaturacurso='$codcurso' AND grupo='$codgrupo'";
$query=pg_query($conexion,$sql);
$numrow=pg_num_rows($query);

if($numrow==0){
    $data="Esta asignatura No tiene Microcurriculo generado. Por favor ingrese MicroCurriculo antes de diligenciar el consignador";
    
}else{
    $data=null;
    
}
print json_encode($data);
?>